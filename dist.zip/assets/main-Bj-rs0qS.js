import{c as t,j as e,A as o}from"./styles-8TqT3zTg.js";t.createRoot(document.getElementById("root")).render(e.jsx(o,{}));
